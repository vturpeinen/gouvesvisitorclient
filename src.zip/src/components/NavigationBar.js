import React, {Component} from 'react';
import {ButtonToolbar} from 'react-bootstrap';
import './Styles/NavigationBar.css';
import {Navbar} from 'react-bootstrap';
import Gouveslogo from '../components/images/gouves-logo.svg';
import '../components/Styles/NavigationBar.css';
/* import Grid from 'react-css-grid' */
/* import MediaQuery from 'react-responsive'; */

class NavigationBar extends Component {
    render () {
        return (
            <nav id="menu" class="navbar navbar-static-top">
                <div class="container">
                    <div class="navbar-header">
                    <Navbar.Brand>
                        <a href="#">
                        <img src={Gouveslogo} className="navbar-logo" alt="logo"/>
                        </a>
                        </Navbar.Brand>
                        <Navbar.Toggle/>
                        </div> 
                        <div class="collapse navbar-collapse" id="navigation">
                        <ul class="border-free">
                        
                       <ButtonToolbar>
                            <form action="#">
                                <button class="btn btn-default navbar-btn">Home</button>
                            </form> 
                            <form action="#">
                                <button class="btn btn-default navbar-btn">About us</button>
                            </form>
                            <form action="#">
                                <button class="btn btn-default navbar-btn">Adoptions</button>
                            </form>
                            <form action="#">
                                <button class="btn btn-default navbar-btn">Ongoing Missions</button>
                            </form>
                            <form action="#">
                                <button class="btn btn-default navbar-btn">How you can help?</button>
                            </form>
                            <form action="#">
                                <button class="btn btn-default navbar-btn">Contact Us</button>
                            </form>
                        </ButtonToolbar>
                        </ul>   
                    </div>
                </div>
         
           </nav>

        );
    }
}
export default NavigationBar;