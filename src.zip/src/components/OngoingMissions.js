import React, { Component } from 'react';

class OngoingMissions extends Component {
    render() {
        return (
            <div>
                <h1>MISSIONS</h1>
            </div>
        );
    }
}

export default OngoingMissions;