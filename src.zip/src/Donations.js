import React, {Component} from 'react';
import './Css/DonationsStyle.css';
import PaypalApp from "./PaypalApp";
import Logo from './Css/Images/gouves-logo-nega.svg';


class Donations extends Component {
    render() {
        return (
            <div className="container-fluid"> {/* <!-- tällä saa containerista responsiivisen --> */}
           <section>
            <div className="Back">
            </div>
            </section>
            <section>
            <div className="Donate_text_box">
            <h1>Donate to the shelter</h1>
            <p>Over 300 homeless and abandoned animals each year find a safe place and needed care with us - <br/>can you help us keep going?
        We do not get any help from the government, or from big organizations, <br/>but depend solely on the donations of individuals.
        Any donation, big or small, is highly appreciated and there are so many ways you can help, <br/>we are sure you will find one suited for your situation.
        We take care of more than 200 dogs and 200 cats, which is a huge task for a group of less than 10 volunteers.</p>
            </div>
            </section>
            <div className="Logo">
                <img className="Logo" src={Logo} height="350px" width="550px" alt="Logo"/>
                </div>
            
            <div className="button_box"></div>
            <div>
            <h2>DONATE</h2>
                    <PaypalApp/>
                    {/*<button className="button">DONATE ONE TIME</button>*/}
                    {/*/!*<NavLink to="/about">ADOPTION ENQUIRY</NavLink>*!/*/}

                    {/*<button className="button">MONTH</button>*/}
                    {/*/!*<NavLink to="/about">ADOPTION ENQUIRY</NavLink>*!/*/}

                </div>
            
         
        
    </div>
            
                
               
                


  

        );
    }
}

export default Donations;