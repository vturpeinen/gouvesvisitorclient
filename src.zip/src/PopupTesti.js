import React, {Component} from 'react';
import Popup from "reactjs-popup";
class PopupTesti extends Component {
    render() {
        return (
            <div>


                export default () => (
                <Popup trigger={<button> Trigger</button>} position="right center">
                    <div>Popup content here !!</div>
                </Popup>
                );
            </div>
        );
    }
}

export default PopupTesti;